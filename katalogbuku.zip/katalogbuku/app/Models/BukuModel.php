<?php

namespace App\Models;

use CodeIgniter\Model;

class BukuModel extends Model
{
    protected $table = 'katalogbuku';
    protected $primarykey = 'id';

    protected $useAutoIncrement = true;
    protected $allowedFields = ['judul', 'kategori', 'status', 'deskripsi', 'slug'];
}