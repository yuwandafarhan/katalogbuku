<?php

namespace App\Controllers;

use App\Models\BukuModel;
use CodeIgniter\Exceptions\PageNotFoundException;

class Buku extends BaseController
{
    public function index()
    {
        //buat object model $buku
        $buku = new BukuModel();

        // siapkan data untuk dikirim ke view dengan nama $Mobiles dan isi datanya dengan Buku yang sudah terbit
        $data['mobiles'] = $buku->where('status', 'published') -> findAll();

        //kirim data ke view
        echo view('buku', $data);
    }

    public function viewBuku($slug)
    {
        $buku = new BukuModel();
        $data['buku'] = $buku->where([
            'slug' => $slug,
            'status' => 'published'
        ])->first();

        // tampilkan 404 error jika data tidak ditemukan
        if (!$data['buku']) {
            throw PageNotFoundException::forPageNotFound();
        }

        echo view('buku_detail', $data);
    }
}