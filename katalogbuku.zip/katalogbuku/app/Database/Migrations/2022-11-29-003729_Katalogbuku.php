<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class Katalogbuku extends Migration
{
    public function up()
    {
        //membuat kolom/field untuk tabel katalogbuku
        $this->forge->addField([
        'id' => [
            'type' => 'int',
            'constraint' => 5,
            'unsigned' => true,
            'auto_increment' => true
        ],
        'judul' => [
            'type' => 'varchar',
            'constraint' => 255
        ],
        'slug' => [
            'type' => 'varchar',
            'constraint' => 255
        ],
        'kategori' => [
            'type' => 'varchar',
            'constraint' => 255
        ],
        'deskripsi' => [
            'type' => 'text',
            'null' => true,
        ],
        'status' => [
            'type' => 'enum',
            'constraint' => ['published', 'draft'],
            'default' => 'draft',
        ]
        ]);

        //membuat primary key
        $this->forge->addKey('id', TRUE);

        //membuat tabel katalogbuku
        $this->forge->createTable('katalogbuku', TRUE);
    }


    public function down()
    {
        //menghapus tabel katalogbuku
        $this->forge->dropTable('katalogbuku');
    }
}
