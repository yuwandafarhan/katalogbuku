<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class Katalogbuku extends Seeder
{
    public function run()
    {
        // membuat data
        $katalogbuku_data = [
            [
                'judul' => 'Memulai Bisnis Dari Nol',
                'slug' => 'memulai-bisnis-dari-nol',
                'kategori' => 'Bisnis',
                'deskripsi' => '2	Memulai Bisnis Dari Nol	memulai-bisnis-dari-nol	Bisnis	Buku Memulai Bisnis dari Nol: Belajar Dari Entrepreneur Top Dunia ini memberikan gambaran bagaimana memulai bisnis dari nol di era Industri 4.0 dengan modal kecil, tetapi mampu melambungkan bisnis kelas dunia, misalnya Apple, Amazon, Walt Disney, Microsoft, Google, Facebook, General Electric, IBM, BMW, Dell Computer, Sony, Wallmart, Coca-Cola, Chrysler, Canon, NEC, Bloomberg, Federal Express, Curve, Charles Schwab, CNN, Gillette, Subaru, Honda, Toyota, Hewlet Packard, Adidas, dan pengalaman saya dalam mengembangkan bisnis. Buku ini membahas perusahaan-perusahaan dan strategi yang harus dibuat untuk menjadi sukses.',
                'status' => 'published'
            ],
            [
                'judul' => 'Buku Siswa Matematika untuk SMA/MA Kelas XI',
                'slug' => 'pendamping-siswa-matematika-xi',
                'kategori' => 'Buku SMA',
                'deskripsi' => 'Buku ini merupakan sebuah pengantar bagi mahasiswa untuk memahami bagaimana manajemen startegik. Buku ini dibuat untuk menunjang mata kuliah Manajemen Strategik di',
                'status' => 'published'
            ],
            [
                'judul' => 'Buku Siswa Fisika untuk SMA/MA Kelas X',
                'slug' => 'pendamping-siswa-fisika-x',
                'kategori' => 'Buku SMA',
                'deskripsi' => 'Buku Teks Pendamping Buku Siswa Fisika untuk SMA/MA Kelas X Kelompok Peminatan Ilmu-Ilmu Pengetahuan Alam ini mengkaji mengenai pembelajaran Fisika yang mengacu pada Kompetensi inti dan Kompetensi Dasar yang telah ditetapkan pada Kurikulum 2013. Materi-materi tersebut disusun dengan bahasa, keterbacaan, dan kegrafikaan yang baik dengan harapan agar mudah dipahami oleh pemakainya.',
                'status' => 'published'
            ],
            [
                'judul' => 'Panduan Asesmen Pendidikan Khusus',
                'slug' => 'asesmen-pendidikan-khusus',
                'kategori' => 'Buku SMA',
                'deskripsi' => 'Setiap guru haruslah menjadi tenaga Profesional, dengan terus selalu meningkatkan kemahirannya dalam melakukan proses pengajaran. Guru yang berkualitas akan menghasilkan peserta didik yang berkualitas pula.',
                'status' => 'published'
            ],
        ];

        foreach ($katalogbuku_data as $data) {
            // insert semua data ke tabel katalogbuku
            $this->db->table('katalogbuku')->insert($data);
        }
    }
}
